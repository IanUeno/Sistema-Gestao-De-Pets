package br.com.pethotel.modelo;

import java.time.LocalDate;

public class Cachorro extends Pet {
    protected String nome;
    protected double peso;
    protected String cor;

    public Cachorro(String nome, String especie, String raca, int idade, double peso, String tutorNome, String tutorContato, LocalDate entrada, Plano plano, String nome1) {
        super(nome, especie, raca, idade, peso, tutorNome, tutorContato, entrada, plano);
        this.nome = nome1;
    }


    @Override
    public void emitirSom(){
        System.out.println("AUUUUUUUU");
    }

    @Override
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
}
