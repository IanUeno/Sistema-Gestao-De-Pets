package br.com.pethotel.sistema;

import br.com.pethotel.modelo.Pet;
import java.sql.*;
import java.io.*;

public class HotelPet {
    private Connection conn;

    public HotelPet() {
        try {
            conn = DriverManager.getConnection("jdbc:sqlite:hotelpet.db");
            inicializarBanco();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void inicializarBanco() throws SQLException {
        Statement stmt = conn.createStatement();
        stmt.execute(
                "CREATE TABLE IF NOT EXISTS pets (id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT, especie TEXT, raca TEXT, idade INTEGER, peso REAL, tutorNome TEXT, tutorContato TEXT, entrada TEXT, plano TEXT)");
        stmt.execute(
                "CREATE TABLE IF NOT EXISTS agendamentos (id INTEGER PRIMARY KEY AUTOINCREMENT, pet_id INTEGER, servico TEXT, dataHora TEXT, FOREIGN KEY(pet_id) REFERENCES pets(id))");
    }

    public void cadastrarPet(Pet pet) {
        try {
            PreparedStatement ps = conn.prepareStatement(
                    "INSERT INTO pets (nome, especie, raca, idade, peso, tutorNome, tutorContato, entrada, plano) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, pet.getNome());
            ps.setString(2, pet.getEspecie());
            ps.setString(3, pet.getRaca());
            ps.setInt(4, pet.getIdade());
            ps.setDouble(5, pet.getPeso());
            ps.setString(6, pet.getTutorNome());
            ps.setString(7, pet.getTutorContato());
            ps.setString(8, pet.getEntrada().toString());
            ps.setString(9, pet.getPlano().name());
            ps.executeUpdate();
            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                int idGerado = generatedKeys.getInt(1);
                System.out.println("Pet cadastrado com sucesso. ID gerado: " + idGerado);
            } else {
                System.out.println("Pet cadastrado, mas ID não pôde ser obtido.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void agendarServico(int petId, String nomeServico, String dataHora) {
        try {
            PreparedStatement ps = conn
                    .prepareStatement("INSERT INTO agendamentos (pet_id, servico, dataHora) VALUES (?, ?, ?)");
            ps.setInt(1, petId);
            ps.setString(2, nomeServico);
            ps.setString(3, dataHora);
            ps.executeUpdate();
            System.out.println("Serviço agendado com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void emitirRelatorioServicos() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT servico, COUNT(*) AS total FROM agendamentos GROUP BY servico");
            System.out.println("Relatório de Serviços Mais Utilizados:");
            while (rs.next()) {
                System.out.println(rs.getString("servico") + " - " + rs.getInt("total") + " vezes");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void emitirRelatorioMensal() {
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT COUNT(DISTINCT pet_id) AS petsAtendidos, COUNT(*) AS totalServicos FROM agendamentos WHERE strftime('%Y-%m', dataHora) = strftime('%Y-%m', 'now')");
            if (rs.next()) {
                System.out.println("Relatório Mensal:");
                System.out.println("Pets atendidos: " + rs.getInt("petsAtendidos"));
                System.out.println("Total de serviços: " + rs.getInt("totalServicos"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void exportarRelatorioCSV(String caminhoArquivo) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(caminhoArquivo))) {
            writer.println("ID Pet,Nome do Pet,Serviço,Data e Hora");
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(
                    "SELECT p.id, p.nome, a.servico, a.dataHora FROM pets p JOIN agendamentos a ON p.id = a.pet_id");
            while (rs.next()) {
                writer.printf("%d,%s,%s,%s",
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("servico"),
                        rs.getString("dataHora"));
            }
            System.out.println("Relatório exportado para: " + caminhoArquivo);
        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }
}
