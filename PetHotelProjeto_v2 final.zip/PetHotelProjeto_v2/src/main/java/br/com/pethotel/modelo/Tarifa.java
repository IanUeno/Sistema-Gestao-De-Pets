package br.com.pethotel.modelo;

import java.time.LocalDateTime;

public interface Tarifa {

    String getNomePlano();

    double calcularHospedagem(LocalDateTime entrada, LocalDateTime saida);
    
    double getTarifaPorHora();

    default double calcularAdicionalEspecie(Pet pet) {
        return getTarifaPorHora();
    }

    String getDescricao();
}