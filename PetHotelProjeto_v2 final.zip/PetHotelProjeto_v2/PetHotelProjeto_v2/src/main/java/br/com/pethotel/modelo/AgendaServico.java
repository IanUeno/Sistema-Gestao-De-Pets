package br.com.pethotel.modelo;

import java.time.LocalDateTime;
import java.util.ArrayList;


public class AgendaServico {
    private ArrayList<Servico> servicosAgendados = new ArrayList<>();

    public boolean agendarServico(Servico novo) {
        for (Servico s : servicosAgendados) {
            LocalDateTime fimAtual = s.getDataHora().plusMinutes(s.getDuracaoMinutos());
            LocalDateTime fimNovo = novo.getDataHora().plusMinutes(novo.getDuracaoMinutos());

            if (!(fimNovo.isBefore(s.getDataHora()) || novo.getDataHora().isAfter(fimAtual))) {
                return false; // conflito
            }
        }
        servicosAgendados.add(novo);
        return true;
    }

    public ArrayList <Servico> getServicos() {
        return servicosAgendados;
    }
}

