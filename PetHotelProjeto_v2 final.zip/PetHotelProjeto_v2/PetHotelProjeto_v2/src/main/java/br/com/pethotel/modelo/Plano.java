
package br.com.pethotel.modelo;

public enum Plano {

    BASICO,
    PREMIUM


}
