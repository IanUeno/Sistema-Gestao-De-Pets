package br.com.pethotel.modelo;

public class Tutor {
    private String nomeTu;
    private int contatoTu;
    public Tutor(String nome, int contato) {
        this.nomeTu = nome;
        this.contatoTu = contato;
    }
    public String getNomeTu() {
        return nomeTu;
    }
    public void setNomeTu(String nomeTu) {
        this.nomeTu = nomeTu;
    }
    public int getContatoTu() {
        return contatoTu;
    }
    public void setContatoTu(int contatoTu) {
        this.contatoTu = contatoTu;
    }

    

}
