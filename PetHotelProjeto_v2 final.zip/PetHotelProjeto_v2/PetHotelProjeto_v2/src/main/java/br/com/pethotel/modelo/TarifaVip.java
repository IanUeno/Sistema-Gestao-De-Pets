package br.com.pethotel.modelo;

import java.time.LocalDateTime;

public class TarifaVip implements Tarifa {

    private static final double VALOR_HORA = 25.0;

    @Override
    public String getNomePlano() {
        return "VIP";
    }


    @Override
    public double getTarifaPorHora() {
        return VALOR_HORA;
    }

    @Override
    public double calcularAdicionalEspecie(Pet pet) {
        if (pet.getEspecie().equalsIgnoreCase("gato")) {
            return 15.0; // VIP pode ter adicionais por espécie
        }
        return 0.0;
    }

    @Override
    public String getDescricao() {
        return "Plano VIP: suíte climatizada, alimentação gourmet e mimos exclusivos.";
    }

    @Override
    public double calcularHospedagem(LocalDateTime entrada, LocalDateTime saida) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calcularHospedagem'");
    }
}