package br.com.pethotel.modelo;

import java.time.LocalDateTime;

public class Servico {
    private String tipo; // banho, tosa, etc.
    private LocalDateTime dataHora;
    private int duracaoMinutos;
    private double preco;
    public Servico(String tipo, LocalDateTime dataHora, int duracaoMinutos, double preco) {
        this.tipo = tipo;
        this.dataHora = dataHora;
        this.duracaoMinutos = duracaoMinutos;
        this.preco = preco;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public LocalDateTime getDataHora() {
        return dataHora;
    }
    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }
    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }
    public void setDuracaoMinutos(int duracaoMinutos) {
        this.duracaoMinutos = duracaoMinutos;
    }
    public double getPreco() {
        return preco;
    }
    public void setPreco(double preco) {
        this.preco = preco;
    }

    
}
