package br.com.pethotel.modelo;

import java.time.Duration;
import java.time.LocalDateTime;

public class TarifaStandard implements Tarifa {
    public double calcularHospedagem(LocalDateTime entrada, LocalDateTime saida) {
        long horas = Duration.between(entrada, saida).toHours();
        return horas * 10.0;
    }

    public String getNomePlano() { return "Standard"; }
    public double getTarifaPorHora() { return 10.0; }

    @Override
    public String getDescricao() {
        throw new UnsupportedOperationException("Unimplemented method 'getDescricao'");
    }
}

