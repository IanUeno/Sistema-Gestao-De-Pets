package br.com.pethotel;

import br.com.pethotel.sistema.HotelPet;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HotelPet hotel = new HotelPet();

        while (true) {
            System.out.println("1. Cadastrar Pet");
            System.out.println("2. Agendar Serviço");
            System.out.println("3. Relatório de Serviços");
            System.out.println("4. Relatório Mensal");
            System.out.println("5. Exportar CSV");
            System.out.println("0. Sair");
            int opcao = sc.nextInt(); sc.nextLine();
            switch (opcao) {
                case 1:
                    
                    System.out.println("Nome do Pet: ");
                    String nome = sc.nextLine();
                    System.out.println("Espécie: ");
                    String especie = sc.nextLine();
                    System.out.println("Raça: ");
                    String raca = sc.nextLine();
                    System.out.println("Idade: ");
                    int idade = sc.nextInt(); sc.nextLine();
                    System.out.println("Peso: ");
                    double peso = sc.nextDouble(); sc.nextLine();
                    System.out.println("Nome do Tutor: ");
                    String tutorNome = sc.nextLine();
                    System.out.println("Contato do Tutor: ");
                    String tutorContato = sc.nextLine();
                    System.out.println("Data de Entrada (AAAA-MM-DD): ");
                    String entrada = sc.nextLine();
                    System.out.println("Plano (BASICO, PREMIUM): ");
                    String planoStr = sc.nextLine();

                    
                    br.com.pethotel.modelo.Plano plano;
                    try {
                        plano = br.com.pethotel.modelo.Plano.valueOf(planoStr.toUpperCase());
                    } catch (IllegalArgumentException e) {
                        System.out.println("Plano inválido. Use BASICO ou PREMIUM.");
                        break;
                    }

                    br.com.pethotel.modelo.Pet pet = new br.com.pethotel.modelo.Pet(
    
                        nome, especie, raca, idade, peso, tutorNome, tutorContato, java.time.LocalDate.parse(entrada), br.com.pethotel.modelo.Plano.valueOf(planoStr.toUpperCase())
                    );
                    hotel.cadastrarPet(pet);
    
                    break;
                case 2:
                    System.out.println("ID do Pet: ");
                    int petId = sc.nextInt(); sc.nextLine();
                    System.out.println("Serviço (Banho, Consulta): ");
                    String servico = sc.nextLine();
                    System.out.println("Data e Hora (AAAA-MM-DDTHH:MM): ");
                    String dataHora = sc.nextLine();
                    hotel.agendarServico(petId, servico, dataHora);
                    break;
                case 3:
                    hotel.emitirRelatorioServicos();
                    break;
                case 4:
                    hotel.emitirRelatorioMensal();
                    break;
                case 5:
                    System.out.println("Informe o caminho do arquivo CSV:");
                    String caminho = sc.nextLine();
                    hotel.exportarRelatorioCSV(caminho);
                    break;
                case 0:
                    return;
            }
        }
    }




}


