
package br.com.pethotel.modelo;

import java.time.LocalDate;

public class Pet {
    private String nome, especie, raca, tutorNome, tutorContato;
    private int idade;
    private double peso;
    private LocalDate entrada;
    private Plano plano;

    public Pet(String nome, String especie, String raca, int idade, double peso,
               String tutorNome, String tutorContato, LocalDate entrada, Plano plano) {
        this.nome = nome;
        this.especie = especie;
        this.raca = raca;
        this.idade = idade;
        this.peso = peso;
        this.tutorNome = tutorNome;
        this.tutorContato = tutorContato;
        this.entrada = entrada;
        this.plano = plano;
    }

    public String getNome() { return nome; }
    public String getEspecie() { return especie; }
    public String getRaca() { return raca; }
    public int getIdade() { return idade; }
    public double getPeso() { return peso; }
    public String getTutorNome() { return tutorNome; }
    public String getTutorContato() { return tutorContato; }
    public LocalDate getEntrada() { return entrada; }
    public Plano getPlano() { return plano; }


    public void emitirSom(){}

}
